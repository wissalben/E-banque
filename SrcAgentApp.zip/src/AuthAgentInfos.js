import {createContext} from 'react'
export const AuthAgentInfos = createContext(null);
