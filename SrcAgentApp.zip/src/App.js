import React,{useReducer} from 'react';
import {BrowserRouter, Route,Switch,Redirect} from 'react-router-dom'
import './App.css';
import {AuthAgentInfos} from './AuthAgentInfos'
import NavBar1 from './AppComponents/AgentComponents/NavBar1';
import NavBar2 from './AppComponents/AgentComponents/NavBar2'
import AuthForm from './AppComponents/AgentComponents/AuthForm';
import AgentOperationsType from './AppComponents/AgentOperationsComponents/AgentOperationsType'
import AgentOperationsClients from './AppComponents/AgentOperationsComponents/AgentOperationsClients'
import AgentOperationsComptes from './AppComponents/AgentOperationsComponents/AgentOperationsComptes'
import PrivateRoute from './AppComponents/PrivateRoute'
import ErrorPage from './AppComponents/ErrorPage'
import EnrollerClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/EnrollerClient'
import ResilierClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/ResilierClient'
import ActiverClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/ActiverClient'
import SuspendreClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/SuspendreClient'
import ConsulterMesClients from './AppComponents/AgentOperationsComponents/OperationsSurClients/ConsulterMesClients'
import ConsulterUnClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/ConsulterUnClient'
import ConsulterComptesClient from './AppComponents/AgentOperationsComponents/OperationsSurClients/ConsulterComptesClient'
import ModifierMDP from './AppComponents/AgentOperationsComponents/OperationsSurClients/ModifierMDP'
import CreerCompteCourant from './AppComponents/AgentOperationsComponents/OperationsSurComptes/CreerCompteCourant'
import CreerCompteEpargne from './AppComponents/AgentOperationsComponents/OperationsSurComptes/CreerCompteEpargne'
import SupprimerCompte from './AppComponents/AgentOperationsComponents/OperationsSurComptes/SupprimerCompte'
import Verser from './AppComponents/AgentOperationsComponents/OperationsSurComptes/Verser'
import Retirer from './AppComponents/AgentOperationsComponents/OperationsSurComptes/Retirer'
import ConsulterUnCompte from './AppComponents/AgentOperationsComponents/OperationsSurComptes/ConsulterUnCompte'
import ConsulterOperationsCompte from './AppComponents/AgentOperationsComponents/OperationsSurComptes/ConsulterOperationsCompte'
import ActiverCompte from './AppComponents/AgentOperationsComponents/OperationsSurComptes/ActiverCompte'
import SuspendreCompte from './AppComponents/AgentOperationsComponents/OperationsSurComptes/SuspendreCompte'
const initialState = {
  isAuth:false,
  agentInformations:{},
  token:{}
}
const reducer = (state, action) => {
switch(action.type){
  case 'agentIsAuthentificated' : 
    return {
      isAuth:true,
      agentInformations:{...action.payload},
      token:{...action.token}

    }
   case 'agentSignedOut' :
     return {
       isAuth:false,
       agentInformations:{},
       token:{}
       
     } 

    default :
    return state
}
}


function App() {
  const [agent,dispatch] = useReducer(reducer, initialState) ;
  return (
    
    <BrowserRouter>
   
    <AuthAgentInfos.Provider value={{agent,dispatch}}>
    <div className="App">
     {agent.isAuth? <NavBar2/>:<NavBar1/>} 
     <Switch>
     <Route  path='/' component={AuthForm} exact/>
     <PrivateRoute  path='/agent/:agent_id' component={AgentOperationsType} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients' component={AgentOperationsClients} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes' component={AgentOperationsComptes} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/enroller-client' component={EnrollerClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/resilier-client' component={ResilierClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/activer-client' component={ActiverClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/suspendre-client' component={SuspendreClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/consulter-mes-clients' component={ConsulterMesClients} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/consulter-un-client' component={ConsulterUnClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/consulter-comptes-client' component={ConsulterComptesClient} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-clients/modifier-mot-de-passe' component={ModifierMDP} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/creer-compte-courant' component={CreerCompteCourant} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/creer-compte-epargne' component={CreerCompteEpargne} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/supprimer-compte' component={SupprimerCompte} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/verser' component={Verser} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/retirer' component={Retirer} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/consulter-compte' component={ConsulterUnCompte} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/consulter-operations-compte' component={ConsulterOperationsCompte} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/activer-compte' component={ActiverCompte} exact/>
     <PrivateRoute  path='/agent/:agent_id/operations-comptes/suspendre-compte' component={SuspendreCompte} exact/>
        
    <Route component={ErrorPage} />
     </Switch>
    </div>
    </AuthAgentInfos.Provider>
   
    </BrowserRouter>
  );
}

export default App;
