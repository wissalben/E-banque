import React from 'react'
import {Route, Redirect} from 'react-router-dom'
import {AuthAgentInfos} from '../AuthAgentInfos' // AuthUserInfos is a context 

function PrivateRoute({component: Component, ...rest}) {

   const {agent, dispatch} =React.useContext(AuthAgentInfos) ;
   

    return (
    <Route {...rest} render={(props) => (
        agent.isAuth == true ? 
         (<Component {...props}/>) : (<Redirect to='/'/>)
        ) }/>
    )
}

export default PrivateRoute
