import {createContext} from 'react'
export const AuthUserInfos = createContext(null);